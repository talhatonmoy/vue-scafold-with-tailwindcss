<a href="javascript:void(0);" class="click cb-category" data-fn="filter" data-source="category" data-item="<#= id #>"><#= icon #><#= name #></a>
