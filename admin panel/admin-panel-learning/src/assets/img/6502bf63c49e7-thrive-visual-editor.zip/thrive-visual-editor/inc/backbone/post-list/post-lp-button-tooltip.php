<div class="control-grid full-width pb-0">
	<span>
		<?php echo esc_html__( 'Landing Page Typography is not available when inheriting active theme typography is enabled.', 'thrive-cb' ); ?>
	</span>
</div>